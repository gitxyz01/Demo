﻿using Domain.Abtract;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebUI.Models;

namespace WebUI.Controllers
{
    public class HomeController : Controller
    {
        private IMainRepository DaPhongThuy;
        public HomeController()
        {
            DaPhongThuy = new Repository();
        }
        public ActionResult Index()
        {
            HomeIndexViewModel model = new HomeIndexViewModel();
            model.Sanphams = DaPhongThuy.SanPhams
                .OrderByDescending(x => x.ProductID)
                .Take(10)
                .ToList();
            return View(model);
        }      
        public ActionResult _HomeHotProductPartial()
        {
            HomeIndexViewModel model = new HomeIndexViewModel();
            model.Sanphams = DaPhongThuy.SanPhams.Where(x => x.SPHot == true)
                .OrderBy(x => x.ProductID)
                .Take(8)
                .ToList();
            return PartialView(model);
        }
        public ActionResult _HomeMenuCategoryPartial()
        {
            var model = DaPhongThuy.DanhMucSanPhams.ToList();
            return PartialView(model);
        }
        public ActionResult _LeftMenuNewProductPartial()
        {
            HomeIndexViewModel model = new HomeIndexViewModel();
            model.Sanphams = DaPhongThuy.SanPhams.OrderByDescending(x => x.ProductID).Take(10).ToList();
            return PartialView(model);
        }       
        public ActionResult _HomeSaleProductPartial()
        {
            HomeIndexViewModel model = new HomeIndexViewModel();
            model.Sanphams = DaPhongThuy.SanPhams.Where(x => x.GiaKhuyenMai > 0).ToList();
            return PartialView(model);
        }        
    }
}