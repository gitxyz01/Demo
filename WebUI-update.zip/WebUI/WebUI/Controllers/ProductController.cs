﻿using Domain.Abtract;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebUI.Models;

namespace WebUI.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        private IMainRepository DaPhongThuy;
        public ProductController()
        {
            DaPhongThuy = new Repository();
        }      
        public ActionResult Index(int page = 1, int category = 0)
        {
            HomeIndexViewModel model = new HomeIndexViewModel();
            model.Sanphams = DaPhongThuy.SanPhams.Where(x => category == 0 || category == x.CategoryProductID)
                .OrderBy(x => x.ProductID)
                .Skip((page - 1) * 10)
                .Take(10)
                .ToList();
            model.CurentCategory = category;
            model.TenDanhMuc = DaPhongThuy.DanhMucSanPhams.Where(x => x.CategoryProductID == model.CurentCategory).Select(x => x.Ten).FirstOrDefault();
            model.PagingInfo = new PagingInfo()
            {
                CurrentPage = page,
                ItemPerPage = 10,
                TotalItem = DaPhongThuy.SanPhams.Where(x => category == 0 || category == x.CategoryProductID).Count()

            };
            return View(model);
        }
                
        public ActionResult ProductDetails(int id)
        {
            var product = DaPhongThuy.SanPhams.FirstOrDefault(x => x.ProductID == id);
            if (product != null)
            {
                return View(product);
            }
            return View();
        }
        public ActionResult _ProductCategoryPartial()
        {
            var model = DaPhongThuy.DanhMucSanPhams.ToList();
            return PartialView(model);
        }
        public ActionResult HotProduct(int page = 1)
        {
            HomeIndexViewModel model = new HomeIndexViewModel();
            model.Sanphams = DaPhongThuy.SanPhams.Where(x => x.SPHot == true)
                .OrderBy(x => x.ProductID)
                .Skip((page - 1) * 4)
                .Take(4)
                .ToList();
            model.PagingInfo = new PagingInfo()
            {
                CurrentPage = page,
                ItemPerPage = 4,
                TotalItem = DaPhongThuy.SanPhams.Where(x => x.SPHot == true).Count()
            };
            return View(model);
        }
    }
}