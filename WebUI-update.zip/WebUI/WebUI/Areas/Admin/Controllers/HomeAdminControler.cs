﻿using Domain.Abtract;
using Domain.Concrete;
using Domain.Entities;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebUI.Models;

namespace  WebUI.Areas.Admin.Controllers
{
 
    [Authorize]
    public class HomeAdminController : Controller
    {
        private IMainRepository DaPhongThuy;
        public HomeAdminController()
        {
            DaPhongThuy = new Repository();
        }
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult _AdminMenuCategoryPartial()
        {
            var model = DaPhongThuy.DanhMucSanPhams.ToList();
            return PartialView(model);
        }
   
    }
}